// ==UserScript==
// @name         1688 Contact Info Extractor
// @namespace    http://tampermonkey.net/
// @version      1.4
// @description  Get contact info from 1688 and export to CSV using a Python MySQL API
// @author       Kaihui
// @match        *://*.1688.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Function to generate a random delay time in milliseconds (1 to 5 seconds)
    function getRandomDelay(minSeconds, maxSeconds) {
        return Math.floor(Math.random() * (maxSeconds - minSeconds + 1) + minSeconds) * 1000;
    }

    // Identify the current page using the URL or hostname
    const url = window.location.href;

    if (url.includes('detail.1688.com')) {
        console.log("1688 detail page detected");
        // 随机延迟时间后点击“联系方式”按钮
        const randomClickDelay = getRandomDelay(1, 3); // 1到3秒之间的随机点击延迟

        setTimeout(() => {
            const contactInfoButton = document.querySelector('li.contactinfo');
            if (contactInfoButton) {
                contactInfoButton.click();
                console.log("Contact info button clicked");

                // 再随机延迟关闭页面
                const randomCloseDelay = getRandomDelay(0, 2); // 0到2秒之间的随机关闭延迟

                setTimeout(() => {
                    console.log("Closing page...");
                    window.close();
                }, randomCloseDelay); // 随机延迟后关闭页面
            } else {
                console.log("Contact info button not found.");
            }
        }, randomClickDelay); // 随机延迟后点击按钮
    }

    else if (url.includes('1688.com/page/contactinfo.htm')) {
        console.log("Contact page detected");
        
        // Function to check if captcha is present
        function isCaptchaPresent() {
            // Detect captcha or punish element based on provided HTML
            return document.querySelector('punish-component') !== null ||
                document.querySelector('#nocaptcha') !== null ||
                document.querySelector('iframe[src*="captcha"]') !== null || // Captcha embedded in iframe
                document.querySelector('.captcha-container') !== null; // Additional captcha container detection
        }

         // Function to handle the captcha page and wait until it's solved
        function waitForCaptchaSolved() {
            console.log("Captcha detected. Waiting for the user to solve it...");

            const observer = new MutationObserver((mutationsList, observer) => {
                if (!isCaptchaPresent()) {
                    console.log("Captcha solved. Continuing with contact info extraction...");
                    observer.disconnect(); // Stop observing once captcha is solved
                    extractContactInfo(); // Continue extracting contact info
                }
            });

            // Start observing changes in the DOM
            observer.observe(document.body, { childList: true, subtree: true });
        }

        function extractContactInfo() {
            const API_URL = 'http://127.0.0.1:5000'; // Flask 服务器地址
            console.log("Extracting contact information...");
            // 保存联系人信息到 Python MySQL API
            function saveToMySQL(contactInfo) {
                fetch(`${API_URL}/saveContact`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(contactInfo)
                })
                    .then(response => response.text())
                    .then(data => console.log('Response from server:', data))
                    .catch(error => console.error('Error saving to MySQL:', error));
            }


            // 监控 JSONP 回调函数
            const originalJsonp = window.mtopjsonp1;
            window.mtopjsonp1 = function(response) {
                console.log('捕捉到 JSONP 请求响应:', response);

                if (response && typeof response === 'object' && response.data && typeof response.data === 'object') {
                    const contactInfo = {
                        name: response.data.name || '',
                        mobileNo: response.data.mobileNo || '',
                        phoneNum: response.data.phoneNum || '',
                        address: response.data.address || '',
                        companyName: response.data.companyName || '',
                        jobTitle: response.data.jobTitle || '',
                        domain: response.data.domain || '',
                        isMale: response.data.isMale ? 'Male' : 'Female',
                        moreInfoLink: response.data.more || '',
                        memberId: response.data.memberId || '',
                        qrCode: response.data.QRCode || '',
                        pageUrl: window.location.href // 保存当前页面的 URL
                    };
                    saveToMySQL(contactInfo);
                } else {
                    console.warn("无效或不完整的响应数据:", response);
                }

                if (originalJsonp) originalJsonp(response);
            };

            // 监控 XMLHttpRequest 响应
            const originalOpen = XMLHttpRequest.prototype.open;
            XMLHttpRequest.prototype.open = function() {
                this.addEventListener('load', function() {
                    if (this.responseType === "" || this.responseType === "text") {
                        console.log('捕捉到 XMLHttpRequest 响应:', this.responseText);
                    } else {
                        console.log('捕捉到 XMLHttpRequest 响应，类型非文本:', this.responseType);
                    }
                });
                originalOpen.apply(this, arguments);
            };

            // Random delay to close the page
            const randomCloseDelay = getRandomDelay(1, 5);
            setTimeout(() => {
                console.log("Closing example.com page after random delay...");
                window.close();
            }, randomCloseDelay);
        }
        if (isCaptchaPresent()) {
            // If captcha is present, wait until it's solved
            waitForCaptchaSolved();
        } else {
            // If no captcha, proceed with extracting contact info
            extractContactInfo();
        }
    }

    else if (url.includes('air.1688.com')) {
        // Main product list page logic
        let currentProductIndex = 0;

        // Function to scroll the product list container and load more products
        function scrollToLoadMore() {
            const productListContainer = document.querySelector('#scrollableDiv');
            if (productListContainer) {
                productListContainer.scrollTo(0, productListContainer.scrollHeight); // Scroll the product list container
                console.log('Scrolled product list container');

                // After scrolling, wait for new products to load
                setTimeout(() => {
                    clickNextProduct(); // Retry clicking the next product
                }, getRandomDelay(1, 2)); // Adjust the delay to allow new products to load
            } else {
                console.error('Product list container not found');
            }
        }

        // Click the next product in the list
        function clickNextProduct() {
            const productLinks = document.querySelectorAll('li.ant-list-item a.inner-rank-page--right--lzGTsap');
            if (currentProductIndex < productLinks.length) {
                const productLink = productLinks[currentProductIndex];
                console.log('Clicking product:', productLink.textContent);
                currentProductIndex++;
                productLink.click(); // Click the product link
            } else {
                // If no more products, scroll to load more
                console.log('All products on this page clicked, scrolling to load more...');
                scrollToLoadMore();
                setTimeout(() => monitorProductLoading(), 2000); // Retry loading products after a delay
            }
        }

        // Function to monitor the product list for new items and ensure that the list is ready before clicking
        function monitorProductLoading() {
            const initialProductCount = document.querySelectorAll('#scrollableDiv > div > div > div > div > div > ul > li').length;

            const intervalId = setInterval(() => {
                const currentProductCount = document.querySelectorAll('#scrollableDiv > div > div > div > div > div > ul > li').length;

                if (currentProductCount > initialProductCount) {
                    console.log('New products loaded, resuming clicks.');
                    clearInterval(intervalId); // Stop the interval once new products are detected
                    clickNextProduct(); // Resume clicking after products are loaded
                }
            }, 1000); // Check every 1 second for new products
        }

        // Start clicking products
        clickNextProduct();

        window.addEventListener('focus', () => {
            setTimeout(() => {
                clickNextProduct();
            }, getRandomDelay(0, 2)); // Give some delay after returning to the list page
        });
    }

    // 在 1688.com 页面添加导出联系人为 CSV 功能
    if (url.includes('1688.com')) {
        console.log("1688.com page detected");

        const API_URL = 'http://127.0.0.1:5000'; // Flask 服务器地址

        // 导出联系人为 CSV
        function exportToCSV() {
            fetch(`${API_URL}/getContacts`)
                .then(response => response.json())
                .then(contacts => {
                    if (contacts.length === 0) {
                        console.log("没有可导出的联系人数据。");
                        return;
                    }

                    let csvContent = "data:text/csv;charset=utf-8,"
                                   + "Name,Mobile No,Phone Num,Address,Company Name,Job Title,Domain,Gender,More Info Link,Member ID,QRCode,Page URL,crawl_time\n";

                    contacts.forEach(contact => {
                        const row = [
                            contact.name,
                            contact.mobileNo,
                            contact.phoneNum,
                            contact.address,
                            contact.companyName,
                            contact.jobTitle,
                            contact.domain,
                            contact.isMale,
                            contact.moreInfoLink,
                            contact.memberId,
                            contact.qrCode,
                            contact.pageUrl, // 添加页面 URL
                            `"${contact.crawl_time}"`
                        ].join(",");
                        csvContent += row + "\r\n";
                    });

                    const encodedUri = encodeURI(csvContent);
                    const link = document.createElement("a");
                    link.setAttribute("href", encodedUri);
                    link.setAttribute("download", "contacts.csv");
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                })
                .catch(error => console.error('Error exporting contacts:', error));
        }

        // 添加导出按钮
        const button = document.createElement('button');
        button.textContent = '导出联系人到CSV';
        button.style.position = 'fixed';
        button.style.bottom = '10px';
        button.style.right = '10px';
        button.style.zIndex = '1000';
        button.style.backgroundColor = '#4CAF50';
        button.style.color = 'white';
        button.style.border = 'none';
        button.style.padding = '10px';
        button.style.cursor = 'pointer';
        button.onclick = exportToCSV;
        document.body.appendChild(button);
    }
})();
